from binascii import hexlify
f = open("file.txt", "r").readlines()

KEY = "REDACTED"
FLAG = "REDACTED"

def xor (s, key) -> str:
	def cycl(a, b):
		if len(b) < len(a):
			i = 0
			while len(b) < len(a):
				b += b[i%len(b)]
				i += 1
		return (a,b)
	a,b = cycl(s,key)
	res = []
	for i,j in zip(a,b): res.append(chr(ord(i) ^ ord(j)))
	ret = hexlify(''.join(res).encode()).decode()
	return ret

t = open("file.txt", "r").readlines()
f = open("enc.txt", "w")

for i in t:
	f.write(xor(i, KEY))
	f.write('\n')
f.close()


f = open("flag.txt", "w")
f.write(xor(FLAG, KEY))
f.close()